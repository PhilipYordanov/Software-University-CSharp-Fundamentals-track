﻿class Person
{
    public string name { get; set; }

    public int Age { get; set; }

}
﻿namespace _08.Raw_Data
{
    public class Tires
    {
        private int tiresAge;
        private double tiresPressure;
       
        public int TiresAges
        {
            get
            {
                return this.tiresAge;
            }
            set
            {
                this.tiresAge = value;
            }
        }

        public double TiresPressure
        {
            get
            {
                return this.tiresPressure;
            }
            set
            {
                this.tiresPressure = value;
            }
        }
      
        public Tires(int age , double pressure)
        {
            this.TiresAges = age;
            this.TiresPressure = pressure;
        }
    }
}

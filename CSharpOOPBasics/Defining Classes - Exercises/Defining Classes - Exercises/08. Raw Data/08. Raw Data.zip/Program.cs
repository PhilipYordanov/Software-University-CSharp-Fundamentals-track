﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _08.Raw_Data
{
    public class Program
    {
        public static void Main()
        {
            var numberOfCars = int.Parse(Console.ReadLine());

            var cars = new List<Car>();

            for (int i = 0; i < numberOfCars; i++)
            {
                var currentCar = Console.ReadLine()
                    .Split();
                var model = currentCar[0];

                var currentEngine = new Engine(int.Parse(currentCar[1]) , int.Parse(currentCar[2]));
                //currentEngine.EngineSpeed = ;
                //currentEngine.EnginePower = ;

                var currentCargoType = new Cargo(int.Parse(currentCar[3]), currentCar[4]);

                var tires = new List<Tires>()
                {
                    new Tires(int.Parse(currentCar[6]), double.Parse(currentCar[5]))
                    , new Tires(int.Parse(currentCar[8]), double.Parse(currentCar[7]))
                    , new Tires(int.Parse(currentCar[10]), double.Parse(currentCar[9]))
                    , new Tires(int.Parse(currentCar[12]), double.Parse(currentCar[11]))
                };

                var car = new Car(model, currentEngine, currentCargoType, tires);
                cars.Add(car);
            }
            var carToPrint = Console.ReadLine();
            if (carToPrint == "flamable")
            {
                cars
                    .Where(c => c.Cargo.Type == "flamable")
                    .Where(x => x.Engine.EnginePower > 250)
                    .ToList()
                    .ForEach(x => Console.WriteLine($"{x.Model}"));
            }
            else
            {
                cars
                    .Where(x => x.Cargo.Type == "fragile")
                    .Where(x => x.Tires.Any(c => c.TiresPressure < 1))
                     .Select(m => m.Model)
                     .ToList()
                     .ForEach(x => Console.WriteLine(x));
            }
        }
    }
}
